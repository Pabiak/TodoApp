import TodoList from "./components/Todo/TodoComponent"
import './App.scss'
const App = () => {
  return (
    <>
     <TodoList/>
    </>
  )
}

export default App
